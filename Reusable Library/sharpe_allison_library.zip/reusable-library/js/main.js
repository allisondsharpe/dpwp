function validateForm() { //Function for validateForm - Used to validate each user input field inside the form

    //COMPETITOR #1
    var x = document.forms["userForm"]["s1_name"].value; //Validates the "s1_name" field
    if (x == null || x == "") {
        alert("Please fill out the name field for competitor 1");
        return false;
    }

    var x = document.forms["userForm"]["s1_score1"].value; //Validates the "s1_score1" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 1 for competitor 1");
        return false;
    }

    var x = document.forms["userForm"]["s1_score2"].value; //Validates the "s1_score2" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 2 for competitor 1");
        return false;
    }

    var x = document.forms["userForm"]["s1_score3"].value; //Validates the "s1_score3" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 3 for competitor 1");
        return false;
    }

    var x = document.forms["userForm"]["s1_score4"].value; //Validates the "s1_score4" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 4 for competitor 1");
        return false;
    }

    var x = document.forms["userForm"]["s1_score5"].value; //Validates the "s1_score5" field
    if (x == null || x == "") {
        alert("Please fill out the final score field for competitor 1");
        return false;
    }

    //COMPETITOR #2

    var x = document.forms["userForm"]["s2_name"].value; //Validates the "s2_name" field
    if (x == null || x == "") {
        alert("Please fill out the name field for competitor 2");
        return false;
    }

    var x = document.forms["userForm"]["s2_score1"].value; //Validates the "s2_score1" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 1 for competitor 2");
        return false;
    }

    var x = document.forms["userForm"]["s2_score2"].value; //Validates the "s2_score2" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 2 for competitor 2");
        return false;
    }

    var x = document.forms["userForm"]["s2_score3"].value; //Validates the "s2_score3" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 3 for competitor 2");
        return false;
    }

    var x = document.forms["userForm"]["s2_score4"].value; //Validates the "s2_score4" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 4 for competitor 2");
        return false;
    }

    var x = document.forms["userForm"]["s2_score5"].value; //Validates the "s2_score5" field
    if (x == null || x == "") {
        alert("Please fill out the final score field for competitor 2");
        return false;
    }

    //COMPETITOR #3

    var x = document.forms["userForm"]["s3_name"].value; //Validates the "s3_name" field
    if (x == null || x == "") {
        alert("Please fill out the name field for competitor 3");
        return false;
    }

    var x = document.forms["userForm"]["s3_score1"].value; //Validates the "s3_score1" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 1 for competitor 3");
        return false;
    }

    var x = document.forms["userForm"]["s3_score2"].value; //Validates the "s3_score2" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 2 for competitor 2");
        return false;
    }

    var x = document.forms["userForm"]["s3_score3"].value; //Validates the "s3_score3" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 3 for competitor 3");
        return false;
    }

    var x = document.forms["userForm"]["s3_score4"].value; //Validates the "s3_score4" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 4 for competitor 3");
        return false;
    }

    var x = document.forms["userForm"]["s3_score5"].value; //Validates the "s3_score5" field
    if (x == null || x == "") {
        alert("Please fill out the final score field for competitor 3");
        return false;
    }

    //COMPETITOR #4

    var x = document.forms["userForm"]["s4_name"].value; //Validates the "s4_name" field
    if (x == null || x == "") {
        alert("Please fill out the name field for competitor 4");
        return false;
    }

    var x = document.forms["userForm"]["s4_score1"].value; //Validates the "s4_score1" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 1 for competitor 4");
        return false;
    }

    var x = document.forms["userForm"]["s4_score2"].value; //Validates the "s4_score2" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 2 for competitor 4");
        return false;
    }

    var x = document.forms["userForm"]["s4_score3"].value; //Validates the "s4_score3" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 3 for competitor 4");
        return false;
    }

    var x = document.forms["userForm"]["s4_score4"].value; //Validates the "s4_score4" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 4 for competitor 4");
        return false;
    }

    var x = document.forms["userForm"]["s4_score5"].value; //Validates the "s4_score5" field
    if (x == null || x == "") {
        alert("Please fill out the final score field for competitor 4");
        return false;
    }

    //COMPETITOR #5

    var x = document.forms["userForm"]["s5_name"].value; //Validates the "s1_name" field
    if (x == null || x == "") {
        alert("Please fill out the name field for competitor 5");
        return false;
    }

    var x = document.forms["userForm"]["s5_score1"].value; //Validates the "s1_score1" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 1 for competitor 5");
        return false;
    }

    var x = document.forms["userForm"]["s5_score2"].value; //Validates the "s5_score2" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 2 for competitor 5");
        return false;
    }

    var x = document.forms["userForm"]["s5_score3"].value; //Validates the "s5_score3" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 3 for competitor 5");
        return false;
    }

    var x = document.forms["userForm"]["s5_score4"].value; //Validates the "s5_score4" field
    if (x == null || x == "") {
        alert("Please fill out the field for score 4 for competitor 5");
        return false;
    }

    var x = document.forms["userForm"]["s5_score5"].value; //Validates the "s5_score5" field
    if (x == null || x == "") {
        alert("Please fill out the final score field for competitor 5");
        return false;
    }

}